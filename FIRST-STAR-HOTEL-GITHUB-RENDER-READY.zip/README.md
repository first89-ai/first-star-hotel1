# FIRST STAR HOTEL & RESORT — REAL PRODUCTION STARTER

นี่เป็นระบบเว็บที่ทำงานจริงแบบ self-hosted สำหรับการจองโรงแรมและการรับชำระเงินแบบ QR/บัญชีธนาคารที่ Admin กำหนดเอง

## มีอะไรทำงานจริง
- PostgreSQL จริง
- Customer booking จริง
- ตรวจ availability จากฐานข้อมูล
- ล็อกห้องผ่าน transaction
- Booking Number จริง
- Countdown จาก server deadline
- QR / Bank Transfer settings จาก Admin
- อัปโหลดสลิป
- Admin Login (JWT + bcrypt)
- Admin approve/reject payment
- เปลี่ยนสถานะ PAYMENT_PENDING → WAITING_VERIFICATION → CONFIRMED
- หมดเวลาชำระ → EXPIRED
- ปล่อย inventory เมื่อหมดเวลาโดย logic ของ availability

## เริ่มระบบ
1. คัดลอก `.env.example` เป็น `.env`
2. เปลี่ยน `JWT_SECRET`, `ADMIN_EMAIL`, `ADMIN_PASSWORD`
3. `docker compose up -d`
4. `npm install`
5. `npm start`
6. เปิด `http://localhost:3000`

## สำคัญก่อนเปิดรับลูกค้าจริง
- ใช้ HTTPS
- ใช้ PostgreSQL ที่มี backup
- เปลี่ยนรหัสผ่าน Admin
- ตั้ง QR/บัญชีธนาคารใน Admin
- ตั้ง domain ของโรงแรม
- จำกัดสิทธิ์/Firewall ของฐานข้อมูล
- ตั้งระบบสำรองไฟล์ upload
- เพิ่ม email/LINE/SMS notification ตามช่องทางจริงของโรงแรม
- ตรวจสอบข้อกำหนด PDPA และการเก็บเอกสารลูกค้า
- ระบบนี้ใช้การตรวจสลิปโดยเจ้าหน้าที่ ไม่ได้ยืนยันยอดเงินจากธนาคารอัตโนมัติ

## Admin ทางลัด
หน้า Customer ไม่มีเมนู Admin. กดโลโก้ FIRST STAR 3 ครั้งภายในช่วงสั้น ๆ จะเปิด `/admin.html` แล้วต้อง Login

## Payment
ลูกค้าจะไม่สามารถตั้งสถานะ PAID เองได้. เฉพาะ Admin ที่ Login แล้วเท่านั้นที่อนุมัติสลิปและเปลี่ยน Booking เป็น CONFIRMED


## GitHub / Render
ไฟล์ `render.yaml` พร้อมสร้าง Web Service + PostgreSQL บน Render และ `DEPLOY-MOBILE.md` มีขั้นตอนสำหรับทำจากมือถือ
