import express from "express";
import path from "node:path";
import fs from "node:fs";
import crypto from "node:crypto";
import { fileURLToPath } from "node:url";
import dotenv from "dotenv";
import helmet from "helmet";
import cors from "cors";
import rateLimit from "express-rate-limit";
import multer from "multer";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import pg from "pg";

dotenv.config();
const { Pool } = pg;
const app = express();
const __dirname = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(__dirname, "..");
const uploadDir = path.join(root, "uploads");
fs.mkdirSync(uploadDir, { recursive: true });

if (!process.env.DATABASE_URL || !process.env.JWT_SECRET) {
  console.error("Missing DATABASE_URL or JWT_SECRET");
  process.exit(1);
}

const pool = new Pool({ connectionString: process.env.DATABASE_URL, max: 10 });
app.use(helmet({ crossOriginResourcePolicy: { policy: "cross-origin" } }));
app.use(cors());
app.use(express.json({ limit: "1mb" }));
app.use(express.urlencoded({ extended: true }));
app.use("/uploads", express.static(uploadDir, { maxAge: "1h" }));
app.use(express.static(path.join(root, "public")));
app.use(rateLimit({ windowMs: 60_000, limit: 120 }));

const upload = multer({
  storage: multer.diskStorage({
    destination: uploadDir,
    filename: (_, file, cb) => cb(null, `${Date.now()}-${crypto.randomUUID()}${path.extname(file.originalname).toLowerCase()}`)
  }),
  limits: { fileSize: 5 * 1024 * 1024 },
  fileFilter: (_, file, cb) => cb(null, /^image\\/(jpeg|png|webp)$/.test(file.mimetype))
});

const money = n => Math.round(Number(n) * 100) / 100;
const nightsBetween = (a,b) => {
  const x = new Date(a + "T00:00:00Z"), y = new Date(b + "T00:00:00Z");
  return Math.ceil((y-x)/86400000);
};
const bookingNo = () => `FSH-${new Date().toISOString().slice(0,10).replaceAll("-","")}-${crypto.randomInt(100000,999999)}`;

async function q(text, params=[]) { return pool.query(text, params); }

function auth(req,res,next){
  try {
    const h=req.headers.authorization||"";
    const token=h.startsWith("Bearer ")?h.slice(7):"";
    req.user=jwt.verify(token, process.env.JWT_SECRET);
    next();
  } catch { res.status(401).json({error:"Unauthorized"}); }
}
function adminOnly(req,res,next){ if(req.user?.role!=="ADMIN") return res.status(403).json({error:"Forbidden"}); next(); }

app.get("/api/health", async (_,res)=>{
  try { await q("SELECT 1"); res.json({ok:true,service:"first-star-hotel"}); }
  catch { res.status(503).json({ok:false}); }
});

app.get("/api/branches", async (_,res)=>{
  const {rows}=await q("SELECT id,name,code,address,phone FROM branches WHERE active=true ORDER BY name");
  res.json(rows);
});

app.get("/api/room-types", async (req,res)=>{
  const branch=req.query.branch_id;
  if(!branch) return res.status(400).json({error:"branch_id required"});
  const {rows}=await q("SELECT id,name,code,price,capacity,description FROM room_types WHERE branch_id=$1 AND active=true ORDER BY price",[branch]);
  res.json(rows);
});

app.get("/api/availability", async (req,res)=>{
  const {branch_id,room_type_id,check_in,check_out}=req.query;
  if(!branch_id||!room_type_id||!check_in||!check_out) return res.status(400).json({error:"missing fields"});
  if(nightsBetween(check_in,check_out)<=0) return res.status(400).json({error:"invalid dates"});
  const {rows}=await q(`
    SELECT r.id,r.room_number,rt.name,rt.price,rt.capacity
    FROM rooms r JOIN room_types rt ON rt.id=r.room_type_id
    WHERE r.branch_id=$1 AND r.room_type_id=$2 AND r.status NOT IN ('MAINTENANCE','OUT_OF_ORDER')
      AND NOT EXISTS (
        SELECT 1 FROM reservations x
        WHERE x.room_id=r.id AND x.status IN ('PAYMENT_PENDING','WAITING_VERIFICATION','CONFIRMED','CHECKED_IN')
          AND x.check_in < $4::date AND x.check_out > $3::date
      )
    ORDER BY r.room_number LIMIT 1`,[branch_id,room_type_id,check_in,check_out]);
  res.json({available:rows.length>0,room:rows[0]||null});
});

app.get("/api/payment-settings/:branchId", async (req,res)=>{
  const {rows}=await q("SELECT qr_enabled,qr_image,bank_enabled,bank_name,account_name,account_number,instructions FROM payment_settings WHERE branch_id=$1",[req.params.branchId]);
  if(!rows[0]) return res.json({qr_enabled:false,bank_enabled:false});
  res.json(rows[0]);
});

app.post("/api/bookings", async (req,res)=>{
  const {branch_id,room_type_id,check_in,check_out,adults=1,children=0,name,phone,email,document_no,special_request}=req.body;
  if(!branch_id||!room_type_id||!check_in||!check_out||!name||!phone) return res.status(400).json({error:"ข้อมูลไม่ครบ"});
  const nights=nightsBetween(check_in,check_out);
  if(nights<=0||nights>60) return res.status(400).json({error:"ช่วงวันเข้าพักไม่ถูกต้อง"});
  const client=await pool.connect();
  try {
    await client.query("BEGIN");
    const rt=await client.query("SELECT * FROM room_types WHERE id=$1 AND branch_id=$2 AND active=true FOR UPDATE",[room_type_id,branch_id]);
    if(!rt.rows[0]) throw new Error("ROOM_TYPE_NOT_FOUND");
    const room=await client.query(`
      SELECT r.* FROM rooms r WHERE r.branch_id=$1 AND r.room_type_id=$2 AND r.status NOT IN ('MAINTENANCE','OUT_OF_ORDER')
      AND NOT EXISTS (SELECT 1 FROM reservations x WHERE x.room_id=r.id AND x.status IN ('PAYMENT_PENDING','WAITING_VERIFICATION','CONFIRMED','CHECKED_IN')
      AND x.check_in < $4::date AND x.check_out > $3::date) ORDER BY r.room_number LIMIT 1 FOR UPDATE`,[branch_id,room_type_id,check_in,check_out]);
    if(!room.rows[0]) throw new Error("NO_ROOM");
    let cust=await client.query("SELECT id FROM customers WHERE phone=$1 LIMIT 1",[phone]);
    const customerId=cust.rows[0]?.id || (await client.query("INSERT INTO customers(name,phone,email,document_no) VALUES($1,$2,$3,$4) RETURNING id",[name,phone,email||null,document_no||null])).rows[0].id;
    const roomAmount=money(Number(rt.rows[0].price)*nights);
    const service=0, vat=0, deposit=0, discount=0;
    const total=money(roomAmount+service+vat+deposit-discount);
    const minutes=Number(process.env.BOOKING_PAYMENT_MINUTES||15);
    const deadline=new Date(Date.now()+minutes*60000);
    const b=bookingNo();
    const r=await client.query(`INSERT INTO reservations
      (booking_number,customer_id,branch_id,room_id,room_type_id,check_in,check_out,adults,children,room_amount,service_charge,vat,deposit,discount,total_amount,payment_deadline,special_request)
      VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17) RETURNING *`,
      [b,customerId,branch_id,room.rows[0].id,room_type_id,check_in,check_out,adults,children,roomAmount,service,vat,deposit,discount,total,deadline,special_request||null]);
    await client.query("INSERT INTO payments(reservation_id,method,amount) VALUES($1,'QR',$2)",[r.rows[0].id,total]);
    await client.query("COMMIT");
    res.status(201).json({booking_number:b,deadline,amount:total,room:room.rows[0].room_number,status:"PAYMENT_PENDING"});
  } catch(e) {
    await client.query("ROLLBACK");
    const msg=e.message==="NO_ROOM"?"ไม่มีห้องว่างในช่วงเวลาที่เลือก":"ไม่สามารถสร้างการจองได้";
    res.status(409).json({error:msg});
  } finally { client.release(); }
});

app.get("/api/bookings/:bookingNumber", async (req,res)=>{
  await expireBookings();
  const {rows}=await q(`SELECT r.*,c.name,c.phone,c.email,rt.name room_type,rm.room_number,b.name branch
    FROM reservations r JOIN customers c ON c.id=r.customer_id JOIN room_types rt ON rt.id=r.room_type_id
    JOIN rooms rm ON rm.id=r.room_id JOIN branches b ON b.id=r.branch_id WHERE r.booking_number=$1`,[req.params.bookingNumber]);
  if(!rows[0]) return res.status(404).json({error:"ไม่พบ Booking"});
  const p=await q("SELECT method,amount,slip_image,status,note FROM payments WHERE reservation_id=$1",[rows[0].id]);
  res.json({...rows[0],payment:p.rows[0]});
});

app.post("/api/bookings/:bookingNumber/slip", upload.single("slip"), async (req,res)=>{
  await expireBookings();
  if(!req.file) return res.status(400).json({error:"กรุณาแนบสลิป JPG/PNG/WEBP ไม่เกิน 5MB"});
  const b=await q("SELECT id,status FROM reservations WHERE booking_number=$1",[req.params.bookingNumber]);
  if(!b.rows[0]) return res.status(404).json({error:"ไม่พบ Booking"});
  if(b.rows[0].status!=="PAYMENT_PENDING") return res.status(409).json({error:"ไม่อยู่ในสถานะรอชำระเงิน"});
  const url=`/uploads/${req.file.filename}`;
  await q("UPDATE payments SET slip_image=$1,status='SUBMITTED',method=COALESCE($2,method) WHERE reservation_id=$3",[url,req.body.method||"QR",b.rows[0].id]);
  await q("UPDATE reservations SET status='WAITING_VERIFICATION' WHERE id=$1",[b.rows[0].id]);
  res.json({ok:true,status:"WAITING_VERIFICATION"});
});

app.post("/api/admin/login", async (req,res)=>{
  const {email,password}=req.body;
  const {rows}=await q("SELECT * FROM admin_users WHERE email=$1 AND active=true",[email]);
  if(!rows[0] || !(await bcrypt.compare(password,rows[0].password_hash))) return res.status(401).json({error:"อีเมลหรือรหัสผ่านไม่ถูกต้อง"});
  const token=jwt.sign({id:rows[0].id,email:rows[0].email,role:rows[0].role},process.env.JWT_SECRET,{expiresIn:"8h"});
  res.json({token});
});

app.get("/api/admin/bookings",auth,adminOnly,async (_,res)=>{
  await expireBookings();
  const {rows}=await q(`SELECT r.booking_number,c.name,c.phone,rt.name room_type,rm.room_number,r.check_in,r.check_out,r.total_amount,r.status,p.status payment_status,p.slip_image
    FROM reservations r JOIN customers c ON c.id=r.customer_id JOIN room_types rt ON rt.id=r.room_type_id JOIN rooms rm ON rm.id=r.room_id
    LEFT JOIN payments p ON p.reservation_id=r.id ORDER BY r.created_at DESC LIMIT 200`);
  res.json(rows);
});

app.post("/api/admin/payments/:bookingNumber/approve",auth,adminOnly,async (req,res)=>{
  const client=await pool.connect();
  try {
    await client.query("BEGIN");
    const r=await client.query("SELECT id,status FROM reservations WHERE booking_number=$1 FOR UPDATE",[req.params.bookingNumber]);
    if(!r.rows[0]) throw new Error("NOT_FOUND");
    if(!["WAITING_VERIFICATION"].includes(r.rows[0].status)) throw new Error("BAD_STATUS");
    await client.query("UPDATE payments SET status='PAID',verified_by=$1,verified_at=now() WHERE reservation_id=$2",[req.user.id,r.rows[0].id]);
    await client.query("UPDATE reservations SET status='CONFIRMED' WHERE id=$1",[r.rows[0].id]);
    await client.query("COMMIT");
    res.json({ok:true,status:"CONFIRMED"});
  } catch(e) {
    await client.query("ROLLBACK");
    res.status(409).json({error:e.message==="NOT_FOUND"?"ไม่พบ Booking":"ไม่สามารถอนุมัติได้"});
  } finally { client.release(); }
});

app.post("/api/admin/payments/:bookingNumber/reject",auth,adminOnly,async (req,res)=>{
  const r=await q("SELECT id FROM reservations WHERE booking_number=$1 AND status='WAITING_VERIFICATION'",[req.params.bookingNumber]);
  if(!r.rows[0]) return res.status(404).json({error:"ไม่พบรายการรอตรวจสอบ"});
  await q("UPDATE payments SET status='REJECTED',note=$1,verified_by=$2,verified_at=now() WHERE reservation_id=$3",[req.body.note||"ไม่ผ่านการตรวจสอบ",req.user.id,r.rows[0].id]);
  await q("UPDATE reservations SET status='PAYMENT_PENDING',payment_deadline=now()+interval '15 minutes' WHERE id=$1",[r.rows[0].id]);
  res.json({ok:true,status:"PAYMENT_PENDING"});
});

app.get("/api/admin/payment-settings/:branchId",auth,adminOnly,async(req,res)=>{
  const {rows}=await q("SELECT * FROM payment_settings WHERE branch_id=$1",[req.params.branchId]);
  res.json(rows[0]||{});
});

app.post("/api/admin/payment-settings/:branchId",auth,adminOnly,upload.single("qr"),async(req,res)=>{
  const {qr_enabled="false",bank_enabled="false",bank_name="",account_name="",account_number="",instructions=""}=req.body;
  const qr=req.file?`/uploads/${req.file.filename}`:(req.body.existing_qr||null);
  await q(`INSERT INTO payment_settings(branch_id,qr_enabled,qr_image,bank_enabled,bank_name,account_name,account_number,instructions)
    VALUES($1,$2,$3,$4,$5,$6,$7,$8)
    ON CONFLICT(branch_id) DO UPDATE SET qr_enabled=$2,qr_image=$3,bank_enabled=$4,bank_name=$5,account_name=$6,account_number=$7,instructions=$8,updated_at=now()`,
    [req.params.branchId,qr_enabled==="true",qr,bank_enabled==="true",bank_name,account_name,account_number,instructions]);
  res.json({ok:true});
});

async function expireBookings(){
  await q(`UPDATE reservations SET status='EXPIRED'
    WHERE status='PAYMENT_PENDING' AND payment_deadline < now()`);
}

async function init(){
  const schema=fs.readFileSync(path.join(root,"db/schema.sql"),"utf8");
  await q(schema);
  const b=await q("SELECT id FROM branches LIMIT 1");
  let branchId=b.rows[0]?.id;
  if(!branchId){
    branchId=(await q("INSERT INTO branches(name,code,address,phone) VALUES($1,$2,$3,$4) RETURNING id",
      ["FIRST STAR HOTEL & RESORT Bangkok","BKK","Bangkok, Thailand","063-547-6681"])).rows[0].id;
    const prices=[["STANDARD Room","STD",790],["Twin Room","TWN",890],["SUPERIOR Room","SUP",990],["DELUXE Room","DLX",1190],["GRAND DELUXE Room","GDL",1490],["FAMILY Room","FAM",2990],["SUITE Room","STE",3990]];
    for(const [name,code,price] of prices){
      const rt=(await q("INSERT INTO room_types(branch_id,name,code,price,capacity) VALUES($1,$2,$3,$4,4) RETURNING id",[branchId,name,code,price])).rows[0].id;
      for(let i=1;i<=6;i++) await q("INSERT INTO rooms(branch_id,room_type_id,room_number) VALUES($1,$2,$3)",[branchId,rt,`${code}-${String(i).padStart(2,"0")}`]);
    }
  }
  const admin=await q("SELECT id FROM admin_users WHERE email=$1",[process.env.ADMIN_EMAIL]);
  if(!admin.rows[0]){
    const hash=await bcrypt.hash(process.env.ADMIN_PASSWORD,12);
    await q("INSERT INTO admin_users(email,password_hash) VALUES($1,$2)",[process.env.ADMIN_EMAIL,hash]);
  }
  const port=Number(process.env.PORT||3000);
  app.listen(port,()=>console.log(`FIRST STAR running on http://localhost:${port}`));
}
init().catch(e=>{console.error(e);process.exit(1)});
