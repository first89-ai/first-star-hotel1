# FIRST STAR — GitHub + Render แบบง่ายที่สุด

## 1) GitHub บนมือถือ
1. เปิด GitHub
2. Create new repository
3. ตั้งชื่อ `first-star-hotel`
4. เลือก Private ถ้าต้องการ
5. แตก ZIP นี้แล้วอัปโหลดไฟล์/โฟลเดอร์ทั้งหมดเข้า repository
6. ตรวจว่า `render.yaml` อยู่หน้าแรกของ repository (root)
7. Commit changes

## 2) Render
เปิด Render Dashboard แล้วเลือก New → Blueprint
เชื่อม GitHub → เลือก `first-star-hotel`
Render จะอ่าน `render.yaml` และสร้าง Web Service + PostgreSQL ตามไฟล์

## 3) Environment Variables ที่ Render จะถาม
- JWT_SECRET = สร้างข้อความสุ่มยาว ๆ เช่น 32–64 ตัวอักษร
- ADMIN_EMAIL = อีเมล Admin จริง
- ADMIN_PASSWORD = รหัสผ่าน Admin ที่แข็งแรง

ไม่ต้องกรอก DATABASE_URL เอง เพราะ render.yaml ผูกกับ Render Postgres ให้อัตโนมัติ

## 4) Deploy
กด Apply / Deploy Blueprint
รอ Build และ Deploy เสร็จ
จากนั้นเปิด URL `.onrender.com`

Customer:
`https://ชื่อบริการ.onrender.com/`

Admin:
กดโลโก้ FIRST STAR 3 ครั้ง → Admin Login
หรือเปิด:
`https://ชื่อบริการ.onrender.com/admin.html`

## 5) ตั้งค่า QR / บัญชีธนาคาร
เข้า Admin → ตั้งค่าช่องทางรับเงิน
- เปิด QR
- อัปโหลด QR จริงของโรงแรม
- หรือเปิด Bank Transfer
- ใส่ธนาคาร / ชื่อบัญชี / เลขบัญชี
- บันทึก

## 6) ก่อนรับลูกค้าจริง
- เปลี่ยน Admin password
- ใช้ QR/บัญชีของโรงแรมจริง
- ทดสอบ Booking 1 รายการ
- ทดสอบ Countdown
- ทดสอบอัปโหลดสลิป
- ทดสอบ Approve / Reject
- ตรวจ Backup ของ PostgreSQL
- เพิ่ม Custom Domain + HTTPS หากต้องการ

### สำคัญ
Render ระบุว่า Free resources ไม่ควรใช้กับ Production และ Free Postgres หมดอายุหลัง 30 วัน ดังนั้นแพ็กเกจนี้ตั้ง Web Service/Database เป็นแผนที่เหมาะกับการใช้งานจริง ไม่ใช่ Free trial
