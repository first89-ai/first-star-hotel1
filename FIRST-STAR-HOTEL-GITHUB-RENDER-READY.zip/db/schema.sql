CREATE EXTENSION IF NOT EXISTS pgcrypto;

CREATE TABLE IF NOT EXISTS branches (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  code TEXT UNIQUE NOT NULL,
  address TEXT,
  phone TEXT,
  active BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS room_types (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  branch_id UUID NOT NULL REFERENCES branches(id),
  name TEXT NOT NULL,
  code TEXT NOT NULL,
  price NUMERIC(12,2) NOT NULL DEFAULT 0,
  capacity INT NOT NULL DEFAULT 2,
  description TEXT,
  active BOOLEAN NOT NULL DEFAULT TRUE,
  UNIQUE(branch_id, code)
);

CREATE TABLE IF NOT EXISTS rooms (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  branch_id UUID NOT NULL REFERENCES branches(id),
  room_type_id UUID NOT NULL REFERENCES room_types(id),
  room_number TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'AVAILABLE'
    CHECK (status IN ('AVAILABLE','OCCUPIED','DIRTY','CLEANING','MAINTENANCE','OUT_OF_ORDER')),
  UNIQUE(branch_id, room_number)
);

CREATE TABLE IF NOT EXISTS customers (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  phone TEXT NOT NULL,
  email TEXT,
  document_no TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS reservations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  booking_number TEXT UNIQUE NOT NULL,
  customer_id UUID NOT NULL REFERENCES customers(id),
  branch_id UUID NOT NULL REFERENCES branches(id),
  room_id UUID NOT NULL REFERENCES rooms(id),
  room_type_id UUID NOT NULL REFERENCES room_types(id),
  check_in DATE NOT NULL,
  check_out DATE NOT NULL,
  adults INT NOT NULL DEFAULT 1,
  children INT NOT NULL DEFAULT 0,
  room_amount NUMERIC(12,2) NOT NULL,
  service_charge NUMERIC(12,2) NOT NULL DEFAULT 0,
  vat NUMERIC(12,2) NOT NULL DEFAULT 0,
  deposit NUMERIC(12,2) NOT NULL DEFAULT 0,
  discount NUMERIC(12,2) NOT NULL DEFAULT 0,
  total_amount NUMERIC(12,2) NOT NULL,
  payment_deadline TIMESTAMPTZ NOT NULL,
  status TEXT NOT NULL DEFAULT 'PAYMENT_PENDING'
    CHECK (status IN ('PAYMENT_PENDING','WAITING_VERIFICATION','CONFIRMED','CANCELLED','EXPIRED','CHECKED_IN','CHECKED_OUT')),
  special_request TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS payment_settings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  branch_id UUID NOT NULL UNIQUE REFERENCES branches(id),
  qr_enabled BOOLEAN NOT NULL DEFAULT FALSE,
  qr_image TEXT,
  bank_enabled BOOLEAN NOT NULL DEFAULT FALSE,
  bank_name TEXT,
  account_name TEXT,
  account_number TEXT,
  instructions TEXT,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS payments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  reservation_id UUID NOT NULL UNIQUE REFERENCES reservations(id),
  method TEXT NOT NULL CHECK (method IN ('QR','BANK_TRANSFER')),
  amount NUMERIC(12,2) NOT NULL,
  slip_image TEXT,
  status TEXT NOT NULL DEFAULT 'PENDING'
    CHECK (status IN ('PENDING','SUBMITTED','PAID','REJECTED')),
  note TEXT,
  verified_by UUID,
  verified_at TIMESTAMPTZ
);

CREATE TABLE IF NOT EXISTS admin_users (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  email TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  role TEXT NOT NULL DEFAULT 'ADMIN',
  active BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_res_dates ON reservations(room_id, check_in, check_out);
CREATE INDEX IF NOT EXISTS idx_res_status ON reservations(status);
